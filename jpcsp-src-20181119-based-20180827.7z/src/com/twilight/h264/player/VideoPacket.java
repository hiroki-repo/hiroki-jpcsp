package com.twilight.h264.player;

public class VideoPacket {
	public int[] payload_base;
	public int payload_offset;
	public int payload_length; 
}
